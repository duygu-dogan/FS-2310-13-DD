import React from 'react'
import { Alert, Container } from 'react-bootstrap'

const Footer = () => {
  return (
    <>
    
      <Alert className='mb-0' variant='info'>
              <Container>
        Bu uygulama FS-2310-13 sınıfı tarafından geliştirilmiştir.
          </Container>
    </Alert>
          
    </>
  )
}

export default Footer